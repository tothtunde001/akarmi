﻿namespace IPfeladat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //beolvassuk a kizárásokat,ez mehet tömbbe,mert ismerjük, hogy hány db sor van benne (csak ip címet tartalmaz)
            string[] Kizárások = File.ReadAllLines(@"D:\Márti\2023.04.17\excluded.csv");

            //beolvassuk a foglaltakat mac_ip adatszerkezetbe
            List<mac_ip> foglaltak = new List<mac_ip>();
            StreamReader beolvas = new StreamReader(@"D:\Márti\2023.04.17\reserved.csv");
            while (!beolvas.EndOfStream)
            {
                foglaltak.Add(new mac_ip(beolvas.ReadLine()));
            }
            beolvas.Close();

            //beolvassuk a dhcp szerver aktuális állapotát mac_ip adatszerkezetbe
            List<mac_ip> dhcp = new List<mac_ip>();
            beolvas = new StreamReader(@"D:\Márti\2023.04.17\dhcp.csv");
            while (!beolvas.EndOfStream)
            {
                dhcp.Add(new mac_ip(beolvas.ReadLine()));
            }
            beolvas.Close();

            //ezek után a test file-t is beolvassuk
            List<test> teszt = new List<test>();
            beolvas = new StreamReader(@"D:\Márti\2023.04.17\test.csv");
            while (!beolvas.EndOfStream)
            {
                string sor = beolvas.ReadLine();
                teszt.Add(new test(sor));
            }
            beolvas.Close();
            foreach (var item in teszt)
            {                
                if (item.Keres == false)
                {
                    //eldobás, ha megtalálom a dhcp listában
                    int i = 0;
                    while (i < dhcp.Count && dhcp[i].Ip != item.Cim)
                    {
                        i++;
                    }
                    if (i < dhcp.Count)
                    {
                        Console.WriteLine(item.Cim + " felszabadítva.");
                        dhcp.RemoveAt(i);
                    }
                    else
                    {
                        Console.WriteLine("Nincs benne ilyen cím.");
                    }
                }
                else
                {                    
                    //hanem dobom el
                    int i = 0;
                    while (i < dhcp.Count && dhcp[i].Mac != item.Cim)
                    {
                        i++;
                    }
                    if (i < dhcp.Count)
                    {
                        Console.WriteLine("Benne volt.");
                    }
                    else
                    {
                        i = 0;
                        while (i < foglaltak.Count && foglaltak[i].Mac != item.Cim)
                        {
                            i++;
                        }
                        if (i < foglaltak.Count)
                        {
                            if (dhcp.Contains(foglaltak[i]) == false)
                            {
                                string s = foglaltak[i].Mac + ";" + foglaltak[i].Ip;
                                dhcp.Add(new mac_ip(s));
                           
                            }
                            else
                            {
                                int IP = 100;
                                while (IP < 200)
                                {
                                    string IPcim = "192.168.10." + IP.ToString();
                                    i = 0;
                                    while (i < dhcp.Count && dhcp[i].Ip != IPcim) //megnézem a dhcp listában
                                    {
                                        i++;
                                    }
                                    if (i < dhcp.Count) //benne van?
                                    {
                                        IP++; //ha benne volt,akkor növelem a címet
                                    }
                                    else //ha nem volt benne meg kellnézni,hogy a kizártak közt van e a cím
                                    {
                                        if (Kizárások.Contains(IPcim))
                                        {
                                            IP++; // ez a cím sem lesz jó, ezért növelem az IP-t
                                        }
                                        else //fenntartokban benne van-e?
                                        {
                                            i = 0;
                                            while (i < foglaltak.Count && foglaltak[i].Ip != IPcim) //megkeresem, hogy az i az kisebb-e mint a foglaltak száma és az foglaltak i nem e egyenlő az adott IPvel
                                            {
                                                i++;
                                            }
                                            if (i < foglaltak.Count)
                                            {
                                                IP++;
                                            }
                                            else
                                            {
                                                string s = item.Cim + ";" + IPcim;
                                                dhcp.Add(new mac_ip(s));
                                                IP = 201; //kiugrik a ciklusból ebben az esetben
                                            }
                                        }
                                    }
                                }
                                if (IP == 200) //mivel max 200-ig vannak kiosztható címek
                                {
                                    Console.WriteLine("Nincs elég cím.");
                                }
                            }
                        }
                    }
                }
            }
            StreamWriter ki = new StreamWriter(@"D:\Márti\2023.04.17\dhcp_kesz.csv");
            foreach (var item in dhcp)
            {
                ki.WriteLine(item.Mac + ";" + item.Ip);
            }
            ki.Close();
        }
    }
}
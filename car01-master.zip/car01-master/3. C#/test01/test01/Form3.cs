﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test01
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string connenstionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=test03;";
            MySqlConnection connection = new MySqlConnection(connenstionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "DELETE FROM `zoo` WHERE `id` VALUES ('" + this.textBox1.Text + "');";
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Sikeres művelet");
        }
    }
}

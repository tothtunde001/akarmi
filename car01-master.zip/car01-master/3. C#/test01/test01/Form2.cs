﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test01
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        /*private void label1_Click(object sender, EventArgs e)
        {
            string connenstionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=test03;";
            MySqlConnection connection = new MySqlConnection(connenstionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "INSERT INTO `zoo` (`id`, `faj`, `kor`, `ev`) VALUES (NULL, '" + this.textBox1.Text + "', '" + this.textBox1.Text + "', '" + this.textBox1.Text + "');";
            command.ExecuteNonQuery();
            connection.Close();
        }*/

        /*private void button1_Click(object sender, EventArgs e)
        {

        }*/

        /*private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }*/

        private void button3_Click(object sender, EventArgs e)
        {
            string connenstionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=test03;";
            MySqlConnection connection = new MySqlConnection(connenstionString);
            connection.Open();
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "INSERT INTO `zoo` (`id`, `faj`, `kor`, `ev`) VALUES (NULL, '" + this.textBox4.Text + "', '" + this.textBox5.Text + "', '" + this.textBox6.Text + "');";
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Sikeres művelet");
        }

        private void button4_Click(object sender, EventArgs e)
        {

            Form3 form3 = new Form3();
            form3.Show();
        }
    }
}

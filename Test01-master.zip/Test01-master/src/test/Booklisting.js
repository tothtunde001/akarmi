import {Link, useParams} from 'react-rooter-dom';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';

const BooksListing = () =>{
    const[bookdata, bookdatachange] = useState(null)
    const navigate = useNavigate();

    const LoadDetail=(id) =>{
        navigate ("/books/dateil/" + id)
    }

    const LoadEdit=(id) =>{
        navigate ("/books/edit/" + id)
    }
}
    const RemoveData=(id) =>{
        if(window.confirm("Do you want remove?"))
        fetch("http://localhost:8000/api/books/" + id,{
            method: "POST",
            headers:{"content-type":"application/json"},
            body: JSON.stringify(bookdata)
        }).then((res) =>{
            alert('Saved SuccessFully');
            window.location.reload();
        }).catch((err) =>{
            console.log(err.message)
        })
}


useEffect(() => {
    fetch("http://localhost:8000/api/books").then((res)=>{
        return res.JSON();
    }).then((resp) =>{
        bookdatachange(resp);
    }).catch((err) =>{
        console.log(err.message)
    })
}, []);

return(
    <div className="row">
    <div className="offset-lg-3 col-lg-6">
        <form className="container">
            <div className="card hatter">
                <h2>Book Listing</h2>
            </div>

            <div className="card-body">
            <div>
                <Link className="btn btn-success" to="books/create"> Add new (+)</Link>
            </div>
            <table className="hatter table">
            <thead className="text-write">
            <tr>
                <td>ID</td>
                <td>Title</td>
                <td>Pages</td>
                <td>Public date</td>
                <td>Actions</td>
            </tr>
            </thead>
                <tbody>
                {bookdata &&
                bookdata.data.map(item=>(
                    <tr key={item.id}>
                        <td>{item.id}</td>
                        <td>{item.title}</td>
                        <td>{item.pages}</td>
                        <td>{item.public_date}</td>
                        <td>
                            <a onClick={()  =>{LoadEdit(item.id)}} className="btn btn-success">Edit</a>
                            <a onClick={()  =>{RemoveData(item.id)}} className="btn btn-danger">Remove</a>
                            <a onClick={()  =>{LoadDetail(item.id)}} className="btn btn-primary">Details</a>
                        </td>
                    </tr>
                ))
                }
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>

);

export default BooksListing;
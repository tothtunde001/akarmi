import { Link, useParams } from 'react-rooter-dom';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';

const BookEdit = () => {

    const { bookid } = useParams();
    // const [bookdata, bookdatachange] = useState({});

    /*useEffect( () =>{
        return resizeBy.JSON();
    }).then((resp)  =>{
        idchange(resp.data.id);
        titlechange(resp.data.title);
        pageschange(resp.data.pages);
        publicdatachange(resp.data.public_data);
    }).catch((err)  =>{
        console.log(err.message);
    })

}, []);*/}

const [id, idchange] = useState('');
const [title, titlechange] = useState('');
const [pages, pageschange] = useState('');
const [public_data, publicdatachange] = useState('');
const navigate = useNavigate();

const handlesubait = (e) => {
    e.prevenDefault();
    const bookdata id string, pages string, public_date string, title string = { id, title, pages, public_date };
    fetch(input "http://localhost:8000/api/books" + bookid, ??? {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(bookdata)
    }).then((res: Response): void => {
        alert('Saved SuccessFully');
        navigate('/')
    }).catch((err): void => {
        console.log(err.message)
    })

}

return {
    < div >

    <div className="row">
        <div className="offset-lg-3 col-lg-6">
            <form className="container" onSubmit={handlesubait}>
                <div className="card hatter">
                    <h2>Books Edit</h2>
                </div>

                <div className="card-body">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>ID</label>
                                <input value={id} disabled="disabled" className="form-control" />
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>Title</label>
                                <input required value={title} onChange={e, :ChangeEvent<HTMLInputElement> => titlechange(e.target.value)} className="form-control"/>
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>Pages</label>
                                <input required value={pages} onChange={e, :ChangeEvent<HTMLInputElement> => pageschange(e.target.value)} className="form-control"/>
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>Public date</label>
                                <input required value={public_date} onChange={e, :ChangeEvent<HTMLInputElement> => public_datechange(e.target.value)} className="form-control"/>
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <button className="btn btn-success" type="submit">Save</button>
                                <Link className="btn btn-danger" to="/">Back</Link>
                            </div>
                        </div>
                    </div>

                </div>
        </div>
    </form>
            </div >
        </div >
    </div >
}


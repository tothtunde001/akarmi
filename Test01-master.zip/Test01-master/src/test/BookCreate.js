import { useState } from "react"
import { useNavigate } from "react-router";

const BookCreate = () =>{
    const[id string, idchange]=useState(mintaState '');
    const[title string, titlechange]=useState(mintaState '');  
    const[pages string, pageschange]=useState(mintaState '');
    const[public_date string, public_datechange]=useState(mintaState '');
    const navigate NavigatesFunction = useNavigate();        

|useage ???

const handlesubait = (e) =>{
    e.preventDefault();
    const bookdata pages string, public_date string, title string = {title, pages, public_date};

    fetch(input "http://localhost:8000/api/books/",???{
        method: "POST",
        headers:{"content-type":"application/json"},
        body: JSON.stringify(bookdata) 
    }).then((res :Response) :void =>{
        alert('Saved SuccessFully');
        navigate('/')
    }).catch((err) :void =>{
        console.log(err.message)
    })
}

return(
    <div>

            <div className="row">
                <div className="offset-lg-3 col-lg-6">
                    <form className="container" onSubmit={handlesubait}>
                        <div className="card hatter">
                            <h2>Books add</h2>
                        </div>

                        <div className="card-body">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>ID</label>
                                        <input value={id} disabled="disabled" className="form-control"/>
                                </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>Title</label>
                                    <input required value={title} onChange={e, :ChangeEvent<HTMLInputElement> => titlechange(e.target.value)} className="form-control"/>
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>Pages</label>
                                    <input required value={pages} onChange={e, :ChangeEvent<HTMLInputElement> => pageschange(e.target.value)} className="form-control"/>
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <label>Public date</label>
                                    <input required value={public_date} onChange={e, :ChangeEvent<HTMLInputElement> => public_datechange(e.target.value)} className="form-control"/>
                            </div>
                        </div>

                        <div className="col-lg-12">
                            <div className="form-group">
                                <button className="btn btn-success" type="submit">Save</button>
                                    <Link className="btn btn-danger" to="/">Back</Link>
                            </div>
                        </div>
                    </div>
                
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

);

}

expect default BookCreate();
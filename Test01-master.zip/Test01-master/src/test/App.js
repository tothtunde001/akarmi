{/* import ??? from 'logo.jpg';*/}
import './App.css';
import {BrowserRouter, Route, Routes} from 'react-rooter-dom';
{/*import { BrowserRouter as Router, Routes, Route } from "react-router-dom";*/}
{/*import { Link } from "react-router-dom";*/}
import Booklisting from "./Booklisting.js";
import BookCreate from "./BookCreate ";
import BookDetail from "./BookDetail";
import BookEdit from "./BookEdit";

function App(){
    return(
        <div className='App'>
        <h1>Harry Potter</h1>

        <BrowserRouter>
            <Route>
                <Routes path='/' element={<Booklisting/>}></Routes>
                <Routes path='/books/create' element={<BookCreate/>}></Routes>
                <Routes path='/books/create/:boowid' element={<BookDetail/>}></Routes>
                <Routes path='/books/edit/:oookid' element={<BookEdit/>}></Routes>
            </Route>
        </BrowserRouter>

        </div>
    );
}

export default App;

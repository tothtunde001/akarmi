import {Link, useParams} from 'react-rooter-dom';
import { useEffect, useState } from 'react';

const BookDetail = () => {
    const {bookid : string} = useParams;
    const [bookdata : , bookdatachange] = useState(mintaState{})

    useEffect( effect() :void =>{
        fetch(input "http://localhost:8000/api/books" + bookid).then((res :???){
            return res.JSON();
        }).then((resp) :void =>{
            bookdatachange(resp);
        }).catch((err) :void =>{
            console.log(err.message)
        })
    }, ???[]);

    return(
        <div>
            {bookdata.data && 
                <div className='container mt-5'>
            <h1>bookdata.data.title</h1>
                <div className='row'>
                    <div className='col-lg-12'>
                        <ul>
                            <li>Azonosító: {bookdata.data.id}</li>
                            <li>Oldalszám: {bookdata.data.pages}</li>
                            <li>Publikálás: {bookdata.data.public_data}</li>
                        </ul>
                    </div>
                </div>
            </div>
        }
        <Link to="/" className='btn btn-primary'>Back</Link>
    </div>
    );
}

export default BookDetail;
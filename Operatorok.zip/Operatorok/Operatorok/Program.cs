﻿using Operatorok;
using System.IO;

namespace Operatorok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<adat> lista = new List<adat>();
            StreamReader be = new StreamReader(@"C:\Users\toth.tunde\Downloads\kifejezesek.txt");

            DateTime kezdes = DateTime.Now;

            int db = 0;
            while (!be.EndOfStream)
            {
                string sor = be.ReadLine();
                lista.Add(new adat(sor));
                if (sor.Contains("mod"))
                {
                    db++;
                }
            }
            be.Close();
            DateTime vege = DateTime.Now;
            Console.WriteLine(vege - kezdes);
            Console.WriteLine("2. feladat: Kifejezések száma: " + lista.Count);
            Console.WriteLine("3. feladat: Kifejezések maradékos osztással: " + db);

            kezdes = DateTime.Now;
            //Másik megoldás a 3. feladathoz
            db = 0;
            foreach (var item in lista)
            {
                if (item.Muvelet == "mod")
                {
                    db++;
                }
            }
            vege = DateTime.Now;
            Console.WriteLine("3. feladat: Kifejezések maradékos osztással: " + db);
            Console.WriteLine(vege - kezdes); //gyorsabb a 2., mert nincs benne file kezelés

            kezdes = DateTime.Now;
            bool volt = false;
            foreach (var item in lista) //ez csúnya Pythonos megoldás
            {
                if (item.Elso % 10 == 0 && item.Masodik % 10 == 0)
                {
                    Console.WriteLine("4. feladat: Van ilyen kifejezés!");
                    volt = true;
                    break;
                }
            }
            //de ez egy ellenőrzés tétel lesz, ezért legyen benne egy boolean, amit megvizsgálok
            if (!volt)
            {
                Console.WriteLine("Nem volt.");
            }
            else
            {
                Console.WriteLine("Volt.");
            }
            vege = DateTime.Now;
            Console.WriteLine(vege - kezdes);

            //megoldás for ciklussal
            kezdes = DateTime.Now;
            volt = false;
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].Elso % 10 == 0 && lista[i].Masodik % 10 == 0)
                {
                    i = lista.Count;
                    volt = true;
                }
            }
            if (!volt)
            {
                Console.WriteLine("Nem volt.");
            }
            else
            {
                Console.WriteLine("Volt.");
            }
            vege = DateTime.Now;
            Console.WriteLine(vege - kezdes);

            //elöltesztelős megoldás
            volt = false;
            kezdes = DateTime.Now;
            int j = 0;
            while (j < lista.Count && !(lista[j].Elso % 10 == 0 && lista[j].Masodik % 10 == 0))
            { j++; }

            kezdes = DateTime.Now;
            Dictionary<string, int> dict = new Dictionary<string, int>();
            foreach (var item in lista)
            {
                if (dict.ContainsKey(item.Muvelet))
                {
                    dict[item.Muvelet]++;
                }
                else
                {
                    dict.Add(item.Muvelet, 1);
                }
            }
            foreach (var item in dict)
            {
                Console.WriteLine(item.Key + " " + item.Value);
            }
            vege = DateTime.Now;
            Console.WriteLine(vege - kezdes);

            //halmazos megoldással, de ezzel 6-7x lassabb
            kezdes = DateTime.Now;
            HashSet<string> halmaz = new HashSet<string>();
            foreach (var item in lista)
            {
                halmaz.Add(item.Muvelet);
            }
            foreach (var item in halmaz)
            {
                db = 0;
                foreach (var item2 in lista)
                {
                    if (item2.Muvelet == item)
                    {
                        db++;
                    }
                }
                Console.WriteLine(item + " " + db);
            }
            vege = DateTime.Now;
            Console.WriteLine(vege - kezdes);

            Dictionary<string, int> dict2 = new Dictionary<string, int>();
            dict2.Add("+", 0);
            dict2.Add("-", 0);
            dict2.Add("*", 0);
            dict2.Add("/", 0);
            dict2.Add("div", 0);
            dict2.Add("mod", 0);

            foreach (var item in lista)
            {
                if (dict2.ContainsKey(item.Muvelet))
                {
                    dict2[item.Muvelet]++;
                }
            }
            foreach (var item in dict2)
            {
                Console.WriteLine(item.Key + " " + item.Value);
            }

            Console.Write("Kérek egy kifejezést: ");
            string egysor = Console.ReadLine();
            try
            {
                string[] darabol = egysor.Split(' ');
                int.Parse(darabol[0]);
                int.Parse(darabol[2]);
                adat muv = new adat(egysor);
                Console.WriteLine(fv(muv));
            }
            catch
            {
                Console.WriteLine("Hibás adat.");
            }
            if (File.Exists(@"C:\Users\toth.tunde\Downloads\eredmenyek.txt"))
            {
                char c = ' ';
                do
                {

                    Console.WriteLine("Felülírod I/N?");
                    c = Console.ReadKey().KeyChar;
                    c = c.ToString().ToUpper()[0];
                    ConsoleKey k = Console.ReadKey().Key;


                } while (c != 'I' && c != 'N');
                if (c == 'I')
                {
                    StreamWriter ki = new StreamWriter(@"C:\Users\toth.tunde\Downloads\eredmenyek.txt");
                    foreach (var item in lista)
                    {
                        ki.WriteLine(fv(item));
                    }
                    ki.Close();
                }
                else
                {
                  
                    StreamWriter ki = new StreamWriter(@"C:\Users\toth.tunde\Downloads\eredmenyek.txt");
                    foreach (var item in lista)
                    {
                        ki.WriteLine(fv(item));
                    }
                    ki.Close();
                }
            }
            
        
            /*StreamWriter ki = new StreamWriter(@"C:\Users\toth.tunde\Downloads\eredmenyek.txt");
            foreach (var item in lista)
            {
                ki.WriteLine(fv(item));
            }
            ki.Close();*/

            string fv(adat vmi)
            {
                string visszater = "";
                if (!dict2.ContainsKey(vmi.Muvelet))
                {
                    visszater = vmi.Elso.ToString() + " " + vmi.Muvelet + " " + vmi.Masodik.ToString() + " = Hibás operátor";
                }
                else
                {
                    double eredmeny = 0;
                    try
                    {
                        switch (vmi.Muvelet)
                        {
                            case "div":
                                eredmeny = vmi.Elso / vmi.Masodik;
                                break;
                            case "mod":
                                eredmeny = vmi.Elso % vmi.Masodik;
                                break;
                            case "+":
                                eredmeny = vmi.Elso + vmi.Masodik;
                                break;
                            case "*":
                                eredmeny = vmi.Elso * vmi.Masodik;
                                break;
                            case "-":
                                eredmeny = vmi.Elso - vmi.Masodik;
                                break;
                            case "/":
                                if (vmi.Masodik != 0)
                                {
                                    eredmeny = (double)vmi.Elso / vmi.Masodik;
                                }
                                else
                                {
                                    eredmeny = vmi.Elso / vmi.Masodik;
                                }
                                break;
                        }
                        visszater = vmi.Elso.ToString() + " " + vmi.Muvelet + " " + vmi.Masodik.ToString() + " = " + eredmeny.ToString();
                    }
                    catch (Exception)
                    {
                        visszater = vmi.Elso.ToString() + " " + vmi.Muvelet + " " + vmi.Masodik.ToString() + " = Hiba";
                    }
                }
                return visszater;
            }

        }
    }
}
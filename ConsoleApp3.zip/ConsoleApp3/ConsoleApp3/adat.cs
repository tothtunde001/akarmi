﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class adat
    {
       
            string nev;
            DateTime datum;
            string nemzetiseg;
            int rajtszam;
            public adat(string sor)
            {
                string[] darabolt = sor.Split(';');
                nev = darabolt[0];
                nemzetiseg = darabolt[2];
                if (darabolt[3]!="")
                { rajtszam = int.Parse(darabolt[3]); }
                else
                {
                    rajtszam = -1;
                }
                darabolt = darabolt[1].Split('.');
                datum = new DateTime(int.Parse(darabolt[0]),
                    int.Parse(darabolt[1]), int.Parse(darabolt[2]));
            }
            public string Nev
            {
                get { return nev; }
                set { nev= value; }
            }
            public DateTime Datum
            { get { return datum; }
            set { datum = value; }
        }
            public string Nemzetiseg
            { get { return nemzetiseg; }
            set
            {
                nemzetiseg = value;
            } }
            public int Rajtszam
            { get { return rajtszam; }
            set
            {
                rajtszam = value;
            } }
        }
    
    }




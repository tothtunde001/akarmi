﻿// See https://aka.ms/new-console-template for more information
using ConsoleApp3;

List<adat> Lista = new List<adat>();
string[] sorok = File.ReadAllLines(@"C:\Users\toth.tunde\Downloads\pilotak.csv");
foreach (var sor in sorok.Skip(1))
{
    Lista.Add(new adat(sor));
}
Console.WriteLine("3.feladat:" + Lista.Count);
Console.WriteLine("4.feladat:" + Lista[Lista.Count-1].Nev);
foreach(adat a in Lista)
{
    //Console.WriteLine(a.Datum);
    if (a.Datum.CompareTo(new DateTime(1901,1,1))>0)
    {
        Console.WriteLine("\t"+a.Nev +" ("+ a.Datum.ToShortDateString()+")");

    }
}
adat min= new adat(";1111.11.11;;"+int.MaxValue);

foreach(var item in Lista)
{ 
    if(item.Rajtszam!=-1&& min.Rajtszam>item.Rajtszam)
    {
        min = item;
    }
}
Console.WriteLine(min.Nemzetiseg);
SortedSet<int>Halmaz=new SortedSet<int>();
foreach (var item in Lista)
{
    Halmaz.Add(item.Rajtszam);
}
foreach (var item in Halmaz)

{
    int db = 0;
    foreach(var item2 in Lista)
    { if(item2.Rajtszam==item)
        { db++; }
    }
    if (db > 1) { Console.WriteLine(item+" "); }
   
        
}
Console.WriteLine();
Dictionary<int, int> d = new Dictionary<int, int>();

foreach (var item in Halmaz)
{
   if(item!=null)
    { d.Add((int)item, 0);
    }
        
    
}
foreach (var item in Lista)
{
    if (item.Rajtszam != null)
    {
        if (d.ContainsKey(item.Rajtszam))
        {
            d[(int)(item.Rajtszam)]++;
        }
    }
}
for(int i= 0; i < d.Count; i++)
{
    if(d.ElementAt(i).Value>1)
    {
        Console.Write(d.ElementAt(i).Key+" ");
    }
}
//bekérünk 1 versenyzőt,adatainak változtatása
//Benne van: a) csere
//b) adjuk hozzá(és mentsük a fájlba is)lehetőleg null nélkül
Console.WriteLine("Add meg a nevet");string nev = Console.ReadLine();
int j = 0;
while (Lista[j].Nev.ToLower() != nev.ToLower() &&j<Lista.Count)
{
    j++;
}
if(j<Lista.Count)
{
    Console.WriteLine("1. Név");
    Console.WriteLine("2. Dátum");
    Console.WriteLine("3. Nemzetiség");
    Console.WriteLine("4. Rajtszám");
    Console.WriteLine();
    char c = Console.ReadLine()[0];
    switch(c)
    {case '1':Console.Write("Add meg az új nevet");
            Lista[j].Nev = Console.ReadLine();
    break;    
    default:
            break;
    }
    StreamWriter ki = new StreamWriter(@"C:\Users\toth.tunde\Downloads\pilotak.csv");
    foreach (var item in Lista)
    {
        ki.WriteLine(item.Nev + ";" + item.Datum + ";" + item.Nemzetiseg + ";"+item.Rajtszam); 
       
    }
    ki.Close();

}
else
{
    Lista.Add(new adat("Alma;2023.3.3;magyar;"));
    StreamWriter ki=File.AppendText(@"C:\Users\toth.tunde\Downloads\pilotak.csv");
    ki.WriteLine("Alma;2023.3.3;magyar;"); 
    ki.Close();
    //b feladat string adat="";
}